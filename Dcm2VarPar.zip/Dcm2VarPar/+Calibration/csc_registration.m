for i=1:100
    m(i)=i
end