# HEXplorer
HEXplorer is am A2L and HEX/S19 file editor.
It allows you to edit, modify and save calibration files used for example in automotive into Engine Control Units.

release 0.7.14 for windows available.

Important remark: 
- all the keywords possibly used into a A2L file from ASAM2 are not yet implemented.
- if you kindly tell me which you need I can support if the win/win cooperation is respected!
- then for BUGS which might occur, please use the issues reporting to get supported.

