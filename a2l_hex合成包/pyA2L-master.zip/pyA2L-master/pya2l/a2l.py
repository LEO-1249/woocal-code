# Generated from a2l.g4 by ANTLR 4.7
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\2\13")
        buf.write("\u00b5\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\4\17\t\17\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3")
        buf.write("\3\3\3\3\3\3\3\3\4\5\4-\n\4\3\4\6\4\60\n\4\r\4\16\4\61")
        buf.write("\3\5\3\5\3\5\6\5\67\n\5\r\5\16\58\3\6\6\6<\n\6\r\6\16")
        buf.write("\6=\3\6\3\6\7\6B\n\6\f\6\16\6E\13\6\3\6\5\6H\n\6\3\6\3")
        buf.write("\6\6\6L\n\6\r\6\16\6M\3\6\5\6Q\n\6\3\6\6\6T\n\6\r\6\16")
        buf.write("\6U\3\6\5\6Y\n\6\3\7\3\7\3\7\3\7\7\7_\n\7\f\7\16\7b\13")
        buf.write("\7\3\7\5\7e\n\7\3\7\3\7\3\7\3\7\3\7\7\7l\n\7\f\7\16\7")
        buf.write("o\13\7\3\7\3\7\5\7s\n\7\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3")
        buf.write("\t\7\t}\n\t\f\t\16\t\u0080\13\t\3\n\3\n\3\n\7\n\u0085")
        buf.write("\n\n\f\n\16\n\u0088\13\n\3\n\3\n\3\13\3\13\5\13\u008e")
        buf.write("\n\13\3\13\6\13\u0091\n\13\r\13\16\13\u0092\3\f\3\f\3")
        buf.write("\r\3\r\3\r\3\r\3\r\5\r\u009c\n\r\3\16\3\16\3\16\3\16\3")
        buf.write("\16\5\16\u00a3\n\16\5\16\u00a5\n\16\5\16\u00a7\n\16\5")
        buf.write("\16\u00a9\n\16\3\17\3\17\3\17\3\17\3\17\3\17\3\17\3\17")
        buf.write("\3\17\5\17\u00b4\n\17\3m\2\20\3\3\5\4\7\5\t\6\13\7\r\b")
        buf.write("\17\t\21\n\23\13\25\2\27\2\31\2\33\2\35\2\3\2\f\4\2--")
        buf.write("//\4\2ZZzz\5\2\62;CHch\4\2\f\f\17\17\5\2\13\f\17\17\"")
        buf.write("\"\5\2C\\aac|\7\2\60\60\62;C\\aac|\4\2$$^^\4\2GGgg\n\2")
        buf.write("$$))^^ddhhppttvv\2\u00cc\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3")
        buf.write("\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2")
        buf.write("\2\2\21\3\2\2\2\2\23\3\2\2\2\3\37\3\2\2\2\5&\3\2\2\2\7")
        buf.write(",\3\2\2\2\t\63\3\2\2\2\13X\3\2\2\2\rr\3\2\2\2\17v\3\2")
        buf.write("\2\2\21z\3\2\2\2\23\u0081\3\2\2\2\25\u008b\3\2\2\2\27")
        buf.write("\u0094\3\2\2\2\31\u0096\3\2\2\2\33\u009d\3\2\2\2\35\u00b3")
        buf.write("\3\2\2\2\37 \7\61\2\2 !\7d\2\2!\"\7g\2\2\"#\7i\2\2#$\7")
        buf.write("k\2\2$%\7p\2\2%\4\3\2\2\2&\'\7\61\2\2\'(\7g\2\2()\7p\2")
        buf.write("\2)*\7f\2\2*\6\3\2\2\2+-\t\2\2\2,+\3\2\2\2,-\3\2\2\2-")
        buf.write("/\3\2\2\2.\60\4\62;\2/.\3\2\2\2\60\61\3\2\2\2\61/\3\2")
        buf.write("\2\2\61\62\3\2\2\2\62\b\3\2\2\2\63\64\7\62\2\2\64\66\t")
        buf.write("\3\2\2\65\67\t\4\2\2\66\65\3\2\2\2\678\3\2\2\28\66\3\2")
        buf.write("\2\289\3\2\2\29\n\3\2\2\2:<\4\62;\2;:\3\2\2\2<=\3\2\2")
        buf.write("\2=;\3\2\2\2=>\3\2\2\2>?\3\2\2\2?C\7\60\2\2@B\4\62;\2")
        buf.write("A@\3\2\2\2BE\3\2\2\2CA\3\2\2\2CD\3\2\2\2DG\3\2\2\2EC\3")
        buf.write("\2\2\2FH\5\25\13\2GF\3\2\2\2GH\3\2\2\2HY\3\2\2\2IK\7\60")
        buf.write("\2\2JL\4\62;\2KJ\3\2\2\2LM\3\2\2\2MK\3\2\2\2MN\3\2\2\2")
        buf.write("NP\3\2\2\2OQ\5\25\13\2PO\3\2\2\2PQ\3\2\2\2QY\3\2\2\2R")
        buf.write("T\4\62;\2SR\3\2\2\2TU\3\2\2\2US\3\2\2\2UV\3\2\2\2VW\3")
        buf.write("\2\2\2WY\5\25\13\2X;\3\2\2\2XI\3\2\2\2XS\3\2\2\2Y\f\3")
        buf.write("\2\2\2Z[\7\61\2\2[\\\7\61\2\2\\`\3\2\2\2]_\n\5\2\2^]\3")
        buf.write("\2\2\2_b\3\2\2\2`^\3\2\2\2`a\3\2\2\2ad\3\2\2\2b`\3\2\2")
        buf.write("\2ce\7\17\2\2dc\3\2\2\2de\3\2\2\2ef\3\2\2\2fs\7\f\2\2")
        buf.write("gh\7\61\2\2hi\7,\2\2im\3\2\2\2jl\13\2\2\2kj\3\2\2\2lo")
        buf.write("\3\2\2\2mn\3\2\2\2mk\3\2\2\2np\3\2\2\2om\3\2\2\2pq\7,")
        buf.write("\2\2qs\7\61\2\2rZ\3\2\2\2rg\3\2\2\2st\3\2\2\2tu\b\7\2")
        buf.write("\2u\16\3\2\2\2vw\t\6\2\2wx\3\2\2\2xy\b\b\2\2y\20\3\2\2")
        buf.write("\2z~\t\7\2\2{}\t\b\2\2|{\3\2\2\2}\u0080\3\2\2\2~|\3\2")
        buf.write("\2\2~\177\3\2\2\2\177\22\3\2\2\2\u0080~\3\2\2\2\u0081")
        buf.write("\u0086\7$\2\2\u0082\u0085\5\31\r\2\u0083\u0085\n\t\2\2")
        buf.write("\u0084\u0082\3\2\2\2\u0084\u0083\3\2\2\2\u0085\u0088\3")
        buf.write("\2\2\2\u0086\u0084\3\2\2\2\u0086\u0087\3\2\2\2\u0087\u0089")
        buf.write("\3\2\2\2\u0088\u0086\3\2\2\2\u0089\u008a\7$\2\2\u008a")
        buf.write("\24\3\2\2\2\u008b\u008d\t\n\2\2\u008c\u008e\t\2\2\2\u008d")
        buf.write("\u008c\3\2\2\2\u008d\u008e\3\2\2\2\u008e\u0090\3\2\2\2")
        buf.write("\u008f\u0091\4\62;\2\u0090\u008f\3\2\2\2\u0091\u0092\3")
        buf.write("\2\2\2\u0092\u0090\3\2\2\2\u0092\u0093\3\2\2\2\u0093\26")
        buf.write("\3\2\2\2\u0094\u0095\t\4\2\2\u0095\30\3\2\2\2\u0096\u009b")
        buf.write("\7^\2\2\u0097\u009c\t\13\2\2\u0098\u009c\5\33\16\2\u0099")
        buf.write("\u009c\13\2\2\2\u009a\u009c\7\2\2\3\u009b\u0097\3\2\2")
        buf.write("\2\u009b\u0098\3\2\2\2\u009b\u0099\3\2\2\2\u009b\u009a")
        buf.write("\3\2\2\2\u009c\32\3\2\2\2\u009d\u00a8\7w\2\2\u009e\u00a6")
        buf.write("\5\27\f\2\u009f\u00a4\5\27\f\2\u00a0\u00a2\5\27\f\2\u00a1")
        buf.write("\u00a3\5\27\f\2\u00a2\u00a1\3\2\2\2\u00a2\u00a3\3\2\2")
        buf.write("\2\u00a3\u00a5\3\2\2\2\u00a4\u00a0\3\2\2\2\u00a4\u00a5")
        buf.write("\3\2\2\2\u00a5\u00a7\3\2\2\2\u00a6\u009f\3\2\2\2\u00a6")
        buf.write("\u00a7\3\2\2\2\u00a7\u00a9\3\2\2\2\u00a8\u009e\3\2\2\2")
        buf.write("\u00a8\u00a9\3\2\2\2\u00a9\34\3\2\2\2\u00aa\u00ab\7^\2")
        buf.write("\2\u00ab\u00ac\4\62\65\2\u00ac\u00ad\4\629\2\u00ad\u00b4")
        buf.write("\4\629\2\u00ae\u00af\7^\2\2\u00af\u00b0\4\629\2\u00b0")
        buf.write("\u00b4\4\629\2\u00b1\u00b2\7^\2\2\u00b2\u00b4\4\629\2")
        buf.write("\u00b3\u00aa\3\2\2\2\u00b3\u00ae\3\2\2\2\u00b3\u00b1\3")
        buf.write("\2\2\2\u00b4\36\3\2\2\2\34\2,\618=CGMPUX`dmr~\u0084\u0086")
        buf.write("\u008d\u0092\u009b\u00a2\u00a4\u00a6\u00a8\u00b3\3\2\3")
        buf.write("\2")
        return buf.getvalue()


class a2l(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    BEGIN = 1
    END = 2
    INT = 3
    HEX = 4
    FLOAT = 5
    COMMENT = 6
    WS = 7
    IDENT = 8
    STRING = 9

    channelNames = [ u"DEFAULT_TOKEN_CHANNEL", u"HIDDEN" ]

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "'/begin'", "'/end'" ]

    symbolicNames = [ "<INVALID>",
            "BEGIN", "END", "INT", "HEX", "FLOAT", "COMMENT", "WS", "IDENT", 
            "STRING" ]

    ruleNames = [ "BEGIN", "END", "INT", "HEX", "FLOAT", "COMMENT", "WS", 
                  "IDENT", "STRING", "EXPONENT", "HEX_DIGIT", "ESC_SEQ", 
                  "UNICODE_ESC", "OCTAL_ESC" ]

    grammarFileName = "a2l.g4"

    def __init__(self, input=None, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


