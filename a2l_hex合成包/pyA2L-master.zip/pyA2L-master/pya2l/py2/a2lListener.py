# Generated from a2l.g4 by ANTLR 4.7
from antlr4 import *

# This class defines a complete listener for a parse tree produced by a2lParser.
class a2lListener(ParseTreeListener):

    # Enter a parse tree produced by a2lParser#a2lFile.
    def enterA2lFile(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#a2lFile.
    def exitA2lFile(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#version.
    def enterVersion(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#version.
    def exitVersion(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#block.
    def enterBlock(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#block.
    def exitBlock(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueIdent.
    def enterValueIdent(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueIdent.
    def exitValueIdent(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueString.
    def enterValueString(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueString.
    def exitValueString(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueInt.
    def enterValueInt(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueInt.
    def exitValueInt(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueHex.
    def enterValueHex(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueHex.
    def exitValueHex(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueFloat.
    def enterValueFloat(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueFloat.
    def exitValueFloat(self, ctx):
        pass


    # Enter a parse tree produced by a2lParser#valueBlock.
    def enterValueBlock(self, ctx):
        pass

    # Exit a parse tree produced by a2lParser#valueBlock.
    def exitValueBlock(self, ctx):
        pass


